from fastapi import FastAPI
import psycopg2
import os
import random

app = FastAPI()

def get_db_connection():
    return psycopg2.connect(
        host="postgres-db",
        database=os.getenv("POSTGRES_DB", "autovapt_db"),
        user=os.getenv("POSTGRES_USER", "myuser"),
        password=os.getenv("POSTGRES_PASSWORD", "mypassword")
    )

# Safely build the table if it doesn't exist
@app.on_event("startup")
def setup_database():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS security_findings (
                id SERIAL PRIMARY KEY,
                target TEXT NOT NULL,
                vulnerability TEXT NOT NULL,
                severity TEXT NOT NULL,
                risk_score FLOAT NOT NULL
            );
        """)
        conn.commit()
        cursor.close()
        conn.close()
    except Exception as e:
        print(f"Database setup failed: {e}", flush=True)

@app.get("/")
def read_root():
    return {"message": "Welcome to AutoVAPT API Gateway!"}

# Trigger the scan simulation safely
@app.get("/run-scan")
def run_scan(target: str):
    try:
        possible_vulns = [
            "SQL Injection Vulnerability", 
            "Cross-Site Scripting (XSS)", 
            "Broken Object Level Authentication",
            "Insecure Deserialization"
        ]
        found_vuln = random.choice(possible_vulns)
        
        # Risk scoring calculation
        cvss_base = round(random.uniform(5.0, 10.0), 1)
        temporal = cvss_base - 0.5
        asset_criticality = 8.0  
        exploit_context = 7.0
        
        final_score = (cvss_base * 0.5) + (temporal * 0.2) + (asset_criticality * 0.2) + (exploit_context * 0.1)
        final_score = round(final_score, 1)
        
        if final_score >= 9.0: severity = "Critical"
        elif final_score >= 7.0: severity = "High"
        else: severity = "Medium"

        # Save to database
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO security_findings (target, vulnerability, severity, risk_score) VALUES (%s, %s, %s, %s);",
            (target, found_vuln, severity, final_score)
        )
        conn.commit()
        cursor.close()
        conn.close()

        return {
            "status": "Scan Completed",
            "target": target,
            "discovered_issue": found_vuln,
            "calculated_severity": severity,
            "final_risk_score": final_score
        }
    except Exception as e:
        # If anything fails, show us the exact error text on the web page!
        return {"status": "Error", "details": str(e)}

@app.get("/findings")
def get_findings():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT target, vulnerability, severity, risk_score FROM security_findings ORDER BY id DESC;")
        rows = cursor.fetchall()
        cursor.close()
        conn.close()
        
        results = []
        for row in rows:
            results.append({
                "target": row[0],
                "vulnerability": row[1],
                "severity": row[2],
                "risk_score": row[3]
            })
        return results
    except Exception as e:
        return {"status": "Error", "details": str(e)}