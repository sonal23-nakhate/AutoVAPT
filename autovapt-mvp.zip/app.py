import streamlit as st
import requests
import pandas as pd

st.set_page_config(page_title="AutoVAPT Dashboard", layout="wide")

st.title("🛡️ AutoVAPT: Enterprise Vulnerability Automation Platform")
st.markdown("---")

col1, col2 = st.columns([1, 2])

# Left side of the screen: Scan Controller
with col1:
    st.subheader("🚀 Trigger Vulnerability Scan")
    target_input = st.text_input("Enter Target URL or IP Address:", placeholder="example.com")
    
    if st.button("Launch Scan", type="primary"):
        if target_input:
            with st.spinner("Running Multi-Factor Risk Scoring Engine..."):
                # Tells our FastAPI backend to run a scan
                response = requests.get(f"http://backend-api:80/run-scan?target={target_input}")
                if response.status_code == 200:
                    st.success("Scan Completed!")
                    st.json(response.json())
                else:
                    st.error("Failed to connect to scanner engine.")
        else:
            st.warning("Please type a target asset address first.")

# Right side of the screen: Database Logs Viewer
with col2:
    st.subheader("📊 Security Findings Logs (PostgreSQL)")
    
    if st.button("Refresh Log Data"):
        st.rerun()

    try:
        # Pulls the active rows from our FastAPI database route
        res = requests.get("http://backend-api:80/findings")
        if res.status_code == 200 and len(res.json()) > 0:
            df = pd.DataFrame(res.json())
            df.columns = ["Target Asset", "Vulnerability Found", "Severity Tier", "Risk Score"]
            st.dataframe(df, use_container_width=True)
        else:
            st.info("No logs saved inside the database yet.")
    except Exception as e:
        st.error("Cannot fetch logs from backend connection.")